How to run without python.
Step 1. Download the Automated-Directory-Archiver-main-exe.zip and unzip wherever you want. This will give you a build directory, dist directory, and an inputfile.txt for custom use and multiple preset input files.

Step 2. Go to your inputfile and replace *Insert year here* with the year you are working on.  You can also use the prebuilt inputfiles. When the code asks for your input file, use the name of the one you are using.

Step 3. Save your inputfile.txt

Step 4. Copy the directory path to reach your inputfile. This is the text at the top that includes the parent folder you are in.

Step 5. Open the Dist folder.

Step 6. Open AutomatedDirectoryArchive.exe. This will open command prompt.

Step 7. Paste the directory path you copied above

Step 8. insert the name of your inputfile.txt. If you did not change the name, this will be inputfile.txt.

Step 9. Let run

Step 10. This will produce a log of what it is doing. It automatically closes when the script is done or if an unknown crash occurs that stops it. You will find a log file and an error log file in the same place your input file is. Please look at it before running again.

Step 11. Check your 4ReadyToLoad folder and see the most recent zip file made there It will either be a zip of the most recent folder it failed to zip, or the last successful one. Try to open it. if it opens, everything is fine. If it gives back an error, Delete the zip file. If you delete it, make sure that the folder it came from originally is moved back to 1ReadyToProcess if it is already in 3Processed.

